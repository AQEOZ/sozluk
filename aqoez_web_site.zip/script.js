const veriler = {
    sayi: 123,
    isim: "Ahmet",
    notlar: [90, 85, 100]
};

function ara() {
    const girilen = document.getElementById("inputField").value.trim();
    const sonucEtiketi = document.getElementById("sonuc");

    if (girilen in veriler) {
        sonucEtiketi.textContent = `Sonuç: ${veriler[girilen]}`;
    } else {
        sonucEtiketi.textContent = "Sonuç bulunamadı.";
    }
}
